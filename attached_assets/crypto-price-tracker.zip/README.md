# Real-Time Crypto Price Tracker

This app displays live-updating crypto prices using React + Redux Toolkit.
